package Main;

import Evaluation.*;
import Reclamation.*;
import Taches.*;
import Utilisateurs.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;


public class Main {
    public static void main(String[] args)  throws ParseException{
        // ======= création des dates =======
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date1 = df.parse("2020-01-25 01:01:01");
        Date date2 = df.parse("2020-02-05 01:01:01");
        Date date3 = df.parse("2020-07-09 01:01:01");
        Date date4 = df.parse("2020-08-09 01:01:01");
        Date date5 = df.parse("2020-09-12 01:01:01");
        Date date6 = df.parse("2020-10-03 01:01:01");
        Date date7 = df.parse("2020-10-05 00:00:00");
        Date date8 = df.parse("2020-10-06 00:00:00");

        // ======= création compétences =======
        Competence c1 = new Competence(1, "sql");
        Competence c2 = new Competence(2, "java");
        Competence c3 = new Competence(3, "c++");
        Competence c4 = new Competence(4, "python");
        Competence c5 = new Competence(5, "Mathématique");
        Competence c6 = new Competence(6, "Economie");
        Competence c7 = new Competence(7, "Management");
        Competence c8 = new Competence(8, "Droit");
        Competence c9 = new Competence(8, "permis type A");
        Competence c10 = new Competence(8, "permis type B");
        Competence c11= new Competence(8, "permis avion");
        Competence c12 = new Competence(8, "permis bateau");


        // ======= création domaine =======
        ArrayList<Competence> lstDomaineComp1 = new ArrayList<>();
        Domaine domaine1 = new Domaine(1, "Education", lstDomaineComp1);
        lstDomaineComp1.add(c5);
        lstDomaineComp1.add(c6);
        lstDomaineComp1.add(c7);
        lstDomaineComp1.add(c8);


        ArrayList<Competence> lstDomaineComp2 = new ArrayList<>();
        Domaine domaine2 = new Domaine(2, "Informatique", lstDomaineComp2);
        lstDomaineComp2.add(c1);
        lstDomaineComp2.add(c2);
        lstDomaineComp2.add(c3);
        lstDomaineComp2.add(c4);


        ArrayList<Competence> lstDomaineComp3 = new ArrayList<>();
        Domaine domaine3 = new Domaine(3, "Transport", lstDomaineComp3);
        lstDomaineComp2.add(c9);
        lstDomaineComp2.add(c10);
        lstDomaineComp2.add(c11);
        lstDomaineComp2.add(c12);


        // ======= création des clients =======
        ArrayList<Evaluation> lstEvalCliPhy1 = new ArrayList<>();
        ArrayList<Domaine> lstDomCliPhy1 = new ArrayList<>();
        ArrayList<Intervenant> lstInterFavCliPhy1 = new ArrayList<>();
        PersonnePhysiqueC clientPhysique1 = new PersonnePhysiqueC(2, "carte d'identité", "France", "Toulouse",
                "rue de bellefontaine", "31300", "330718632342",
                "FR76 5484 6516 5415 2025 6514 212", 3.9f, lstEvalCliPhy1, lstDomCliPhy1,
                lstInterFavCliPhy1, "133@gmail.com", "96324", "Laporte", "Sylvie", "Mlle");


        ArrayList<Evaluation> lstEvalCliMor1 = new ArrayList<>();
        ArrayList<Domaine> lstDomCliMor1 = new ArrayList<>();
        ArrayList<Intervenant> lstInterFavCliMor1 = new ArrayList<>();

        PersonneMoraleC clientMorale1 = new PersonneMoraleC(1, "passeport", "France", "Paris",
                "6 rue de cheval", "94301", "330715963452",
                "FR76 5484 6516 5415 2025 6514 211", 3.7f, lstEvalCliMor1, lstDomCliMor1,
                lstInterFavCliMor1, "130@gmail.com", "154", 235, "Dolt",
                "grande");


        // ======= création des intervenants =======
        // intervenant physique 1
        ArrayList<Evaluation> lstEvalInterPhy1 = new ArrayList<>(); // à instancer
        HashMap<Domaine, ArrayList<Competence>> hmDoCoInterPhy1 = new HashMap<>(); // à instancer

        Competence[] lstCompIP1Dom1 = new Competence[]{c5,c6};
        ArrayList<Competence> lstCompInterPhy1Dom1 = new ArrayList<>(Arrays.asList(lstCompIP1Dom1));
        hmDoCoInterPhy1.put(domaine1, lstCompInterPhy1Dom1);

        Competence[] lstCompIP1Dom2 = new Competence[]{c1,c2};
        ArrayList<Competence> lstCompInterPhy1Dom2 = new ArrayList<>(Arrays.asList(lstCompIP1Dom2));
        hmDoCoInterPhy1.put(domaine2, lstCompInterPhy1Dom2);

        PersonnePhysiqueI intervenantPhysique1 = new PersonnePhysiqueI(1, "passeport","France",
                "Paris ","rue de chat","93201", "330652596671",
                "FR76 5484 6516 5415 2025 6514 213", 4.5f, lstEvalInterPhy1,
                "130@163.com", "555", hmDoCoInterPhy1, "PETIT", "Martin", "M.");


        // intervenant physique 2
        ArrayList<Evaluation> lstEvalInterPhy2 = new ArrayList<>(); // à instancer
        HashMap<Domaine, ArrayList<Competence>> hmDoCoInterPhy2 = new HashMap<>(); // à instancer

        Competence[] lstCompIP2Dom3 = new Competence[]{c10, c11};
        ArrayList<Competence> lstCompInterPhy2Dom3 = new ArrayList<>(Arrays.asList(lstCompIP2Dom3));
        hmDoCoInterPhy2.put(domaine3, lstCompInterPhy2Dom3);

        PersonnePhysiqueI intervenantPhysique2 = new PersonnePhysiqueI(2, "passeport","Chine",
                "Toulouse ","rue de lafayette","31000", "330658626671",
                "FR76 5484 6516 5415 2025 6514 215", 4.7f, lstEvalInterPhy2,
                "139@163.com", "862", hmDoCoInterPhy2, "Laurent", "Sylvain", "M.");


        // intervenant morale 1
        ArrayList<Evaluation> lstEvalInterMorale1 = new ArrayList<>(); // à instancer
        Competence[] lstCompIM1Dom2 = new Competence[]{c1, c2, c3, c4};
        ArrayList<Competence> lstCompInterMor1Dom2 = new ArrayList<>(Arrays.asList(lstCompIM1Dom2));
        HashMap<Domaine, ArrayList<Competence>> hmDoCoInterMorale1 = new HashMap<>(); // à instancer
        hmDoCoInterMorale1.put(domaine2, lstCompInterMor1Dom2);
        PersonneMoraleI intervenantMorale1 = new PersonneMoraleI(3, "carte d'identité","France",
                "Lyon","41 quai Pierre Scize","69009", "330478289755",
                "FR76 5484 6516 5415 2025 6514 214", 4.7f, lstEvalInterMorale1,
                "pierre@gmail.com", "853", hmDoCoInterMorale1, 123,"3Tech", "petite");



        // ======= création des evaluations =======
        Evaluation evaluation1 = new Evaluation(4.6f, "gentil", date3, clientPhysique1, clientPhysique1, intervenantMorale1);
        Evaluation evaluation2 = new Evaluation(4f,"e2d2Tres bon!",date4, intervenantMorale1, clientPhysique1, intervenantMorale1);
        Evaluation evaluation3 = new Evaluation(3.53f,"e3d3Tres bon!",date5,clientMorale1, clientMorale1, intervenantPhysique1);
        Evaluation evaluation4 = new Evaluation(3.7f,"e4d4Tres bon!",date6,intervenantPhysique1, clientMorale1, intervenantPhysique1);

        lstEvalCliPhy1.add(evaluation1);
        lstEvalInterMorale1.add(evaluation2);
        lstEvalCliMor1.add(evaluation3);
        lstEvalInterPhy1.add(evaluation4);

//        System.out.println(clientPhysique1.setPointEvalu());
//        System.out.println(clientPhysique1.get10Commentaires());



        // ======= création des livraisons =======
        Livraison livraison1 = new Livraison("https://www.cnblogs.com/vipstone/p/12683829.html", date1);
        Livraison livraison2 = new Livraison("https://www.runoob.com/try/runcode.php?filename=date_demo1&type=java", date2);
        Livraison livraison3 = new Livraison("https://blog.csdn.net/moakun/article/details/78638570", date3);
        Livraison livraison4 = new Livraison("https://blog.csdn.net/jeffleo/article/details/52175998", date8);



        // ======= création tache simple =======
        //---- création tache simple 1 ----
        // création hashmap des domaines et des compétences pour tache simple 1
        System.out.println("\n======= Tâche simple 1 =======");
        HashMap<Domaine, ArrayList<Competence>> hmDoCoTS1 = new HashMap<>();
        Competence[] lstCompTS1 = new Competence[]{c5, c6}; // math, eco
        ArrayList<Competence> lstCompDom1TS1 = new ArrayList<>(Arrays.asList(lstCompTS1));
        hmDoCoTS1.put(domaine1, lstCompDom1TS1);

        // création hashmap des intervenants et ses livraisons pour tache simple 1
        HashMap<Intervenant, Livraison> lstInterLivTS1 = new HashMap<>();
        lstInterLivTS1.put(intervenantPhysique1,livraison1);
        TacheSimple tacheSimple1 = new TacheSimple(1, "consultation économique",
                "consultation économique pour créer une nouvelle entreprise",
                "", "", date1, date2, "USD 50/heure", EtatTache.PUBLIEE, clientMorale1,
                lstInterLivTS1, hmDoCoTS1);
        System.out.println(tacheSimple1);


        //---- création tache simple 2 ----
        // création hashmap des domaines et des compétences pour tache simple 2
//        System.out.println("\n======= Tâche simple 2 =======");
        HashMap<Domaine, ArrayList<Competence>> hmDoCoTS2 = new HashMap<>();
        Competence[] lstCompTS2 = new Competence[]{c10}; // permis B
        ArrayList<Competence> lstCompDom1TS2 = new ArrayList<>(Arrays.asList(lstCompTS2));
        hmDoCoTS2.put(domaine3, lstCompDom1TS2);

        // création hashmap des intervenants et ses livraisons pour tache simple 2
        HashMap<Intervenant, Livraison> lstInterLivTS2 = new HashMap<>();
        lstInterLivTS2.put(intervenantPhysique2,livraison4);
        TacheSimple tacheSimple2 = new TacheSimple(2, "un jour de taxi",
                "déplacement de Toulouse à Paris", "Paris", "France",
                date6, date7, "EURO 100/jour", EtatTache.PUBLIEE, clientPhysique1,
                lstInterLivTS2, hmDoCoTS2);
//        System.out.println(tacheSimple2);



        // ======= création tache massive =======
        // création hashmap des domaines et des compétences pour tache massive 1
        System.out.println("\n======= Tâche massive 1 =======");
        HashMap<Domaine, ArrayList<Competence>> hmDoCoTM1 = new HashMap<>();
        Competence[] lstCompTM1 = new Competence[]{c1, c2};
        ArrayList<Competence> lstCompDom1TM1 = new ArrayList<>(Arrays.asList(lstCompTM1));
        hmDoCoTM1.put(domaine2, lstCompDom1TM1);

        // création hashmap des intervenants et ses livraisons pour tache massive 1
        HashMap<Intervenant, Livraison> lstInterLivTM1 = new HashMap<>();
        lstInterLivTM1.put(intervenantPhysique1,livraison2);
        lstInterLivTM1.put(intervenantMorale1,livraison3);
        TacheMassive tacheMassive1 = new TacheMassive(3, "développement application commerciale",
                "développement une aplliacation de la gestion de commande en utilisant java et MySQL", "t", "t",
                date2, date3, "EURO 150/jour", EtatTache.PUBLIEE, clientMorale1, lstInterLivTM1, hmDoCoTM1);
        System.out.println(tacheMassive1);


        // ======= création tache complexe =======
        System.out.println("\n======= Tâche complexe 1 =======");
        TacheSimple[] lstTSTC1 = new TacheSimple[]{tacheSimple1};
        ArrayList<TacheSimple> lstTSdeTC1 = new ArrayList<>(Arrays.asList(lstTSTC1));

        TacheMassive[] lstTMTC1 = new TacheMassive[]{tacheMassive1};
        ArrayList<TacheMassive> lstTMdeTC1 = new ArrayList<>(Arrays.asList(lstTMTC1));

        TacheComplexe tacheComplexe1 = new TacheComplexe(4, "développement interface commerciale",
                "développement d'une interface commerciale", lstTSdeTC1, lstTMdeTC1);
        System.out.println(tacheComplexe1);


        // ======= réclamation =======
        System.out.println("\n======= Réclamation 1 =======");
        Reclamation rec1 = new Reclamation(1,
                "On décide de faire le remboursement au client car l'intervenant a dépassé le délai sans raison.",
                EtatReclamation.ACCEPTEE,
                new SimpleDateFormat("2020-02-02"), new SimpleDateFormat("2020-02-04"),
                "La tâche a été dépassé le délai sans raison.", clientPhysique1, intervenantPhysique1,
                clientPhysique1, tacheSimple1, 1000);
        System.out.println(rec1);
    }
}
