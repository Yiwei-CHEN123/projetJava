import Evaluation.*;
import Reclamation.*;
import Taches.*;
import Utilisateurs.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;


public class Main {
    public static void main(String[] args)  throws ParseException{
        // ======= création des dates =======
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date1 = df.parse("2020-12-25 01:01:01");
        Date date2 = df.parse("2020-02-03 01:01:01");
        Date date3 = df.parse("2019-09-09 01:01:01");
        Date date4 = df.parse("2019-09-09 01:01:01");



        // ======= création des clients =======
        ArrayList<Evaluation> lstEvalClient1 = new ArrayList<>();
        ArrayList<Domaine> lstDomaineClient1 = new ArrayList<>();
        ArrayList<Intervenant> lstInterFavorableClient1 = new ArrayList<>();
        Client client1 = new Client(1, "passeport", "France", "Paris", "6 rue de cheval",
                "94301", "330715963452", "FR76 5484 6516 5415 2025 6514 211", 3.7f,
                lstEvalClient1, lstDomaineClient1, lstInterFavorableClient1, "130@gmail.com", "154");


        ArrayList<Evaluation> lstEvalClient2 = new ArrayList<>();
        ArrayList<Domaine> lstDomaineClient2 = new ArrayList<>();
        ArrayList<Intervenant> lstInterFavorableClient2 = new ArrayList<>();
        Client client2 = new Client(2, "carte d'identité", "France", "Toulouse",
                "rue de bellefontaine", "31300", "330718632342",
                "FR76 5484 6516 5415 2025 6514 212", 3.9f, lstEvalClient2, lstDomaineClient2,
                lstInterFavorableClient2, "133@gmail.com", "96324");



        // ======= création des intervenants =======
        ArrayList<Evaluation> lstEvalInterPhy1 = new ArrayList<>(); // à instancer
        HashMap<Domaine, ArrayList<Competence>> hmDoCoInterPhy1 = new HashMap<>(); // à instancer
        PersonnePhysiqueI intervenantPhysique1 = new PersonnePhysiqueI(1, "passeport","France",
                "Paris ","rue de chat","93201", "330652596671",
                "FR76 5484 6516 5415 2025 6514 213", 4.5f, lstEvalInterPhy1,
                "130@163.com", "555", hmDoCoInterPhy1, "MARTIN", "PETIT", "M.");


        ArrayList<Evaluation> lstEvalInterMorale1 = new ArrayList<>(); // à instancer
        HashMap<Domaine, ArrayList<Competence>> hmDoCoInterMorale1 = new HashMap<>(); // à instancer
        PersonneMoraleI intervenantMorale1 = new PersonneMoraleI(1, "carte d'identité","France",
                "Lyon","41 quai Pierre Scize","69009", "330478289755",
                "FR76 5484 6516 5415 2025 6514 214", 4.7f, lstEvalInterMorale1,
                "pierre@gmail.com", "853", hmDoCoInterMorale1, 123,"Dolt", "petite");



        // ======= création des evaluations =======
        Evaluation evaluation1 = new Evaluation(4.6f, "gentil", date1, client1, client1, intervenantMorale1);
        Evaluation evaluation2 = new Evaluation(4f,"e2d2Tres bon!",date2, intervenantMorale1, client1, intervenantMorale1);
        Evaluation evaluation3 = new Evaluation(3.53f,"e3d3Tres bon!",date3,client2, client2, intervenantPhysique1);
        Evaluation evaluation4 = new Evaluation(2.75f,"e4d4Tres bon!",date4,intervenantPhysique1, client2, intervenantPhysique1);

        lstEvalClient1.add(evaluation1);
        lstEvalInterMorale1.add(evaluation2);
        lstEvalClient2.add(evaluation3);
        lstEvalInterPhy1.add(evaluation4);

        System.out.println(client1.setPointEvalu());
        System.out.println(client1.get10Commentaires());



        // ======= création des livraisons =======
        Livraison livraison1 = new Livraison("https://www.cnblogs.com/vipstone/p/12683829.html", date1);
        Livraison livraison2 = new Livraison("https://www.runoob.com/try/runcode.php?filename=date_demo1&type=java", date2);
        Livraison livraison3 = new Livraison("https://blog.csdn.net/moakun/article/details/78638570", date3);
        Livraison livraison4 = new Livraison("https://blog.csdn.net/jeffleo/article/details/52175998", date4);



        // ======= création compétences =======
        Competence c1 = new Competence(1, "sql");
        Competence c2 = new Competence(2, "java");
        Competence c3 = new Competence(3, "c++");
        Competence c4 = new Competence(4, "python");
        Competence c5 = new Competence(5, "Mathématique");
        Competence c6 = new Competence(6, "Economie");
        Competence c7 = new Competence(7, "Management");
        Competence c8 = new Competence(8, "Droit");
        Competence c9 = new Competence(8, "permis type A");
        Competence c10 = new Competence(8, "permis type B");
        Competence c11= new Competence(8, "permis avion");
        Competence c12 = new Competence(8, "permis bateau");




        // ======= création domaine =======
        ArrayList<Competence> lstDomaineComp1 = new ArrayList<>();
        Domaine domaine1 = new Domaine(1, "Education", lstDomaineComp1);
        lstDomaineComp1.add(c5);
        lstDomaineComp1.add(c6);
        lstDomaineComp1.add(c7);
        lstDomaineComp1.add(c8);


        ArrayList<Competence> lstDomaineComp2 = new ArrayList<>();
        Domaine domaine2 = new Domaine(2, "Informatique", lstDomaineComp2);
        lstDomaineComp2.add(c1);
        lstDomaineComp2.add(c2);
        lstDomaineComp2.add(c3);
        lstDomaineComp2.add(c4);


        ArrayList<Competence> lstDomaineComp3 = new ArrayList<>();
        Domaine domaine3 = new Domaine(3, "Transport", lstDomaineComp3);
        lstDomaineComp2.add(c9);
        lstDomaineComp2.add(c10);
        lstDomaineComp2.add(c11);
        lstDomaineComp2.add(c12);



        // ======= création tache simple =======
        // création hashmap des domaines et des compétences pour tache simple 1
        ArrayList<Competence> lstCompDom1TS1 = new ArrayList<>();
        lstCompDom1TS1.add(c1);
        lstCompDom1TS1.add(c2);
        HashMap<Domaine, ArrayList<Competence>> hmDoCoTS1 = new HashMap<>();
        hmDoCoTS1.put(domaine1, lstCompDom1TS1);

        // création hashmap des intervenants et ses livraisons pour tache simple 1
        HashMap<Intervenant, Livraison> lstInterLivTS1 = new HashMap<>();
        lstInterLivTS1.put(intervenantPhysique1,livraison1);
        TacheSimple tacheSimple1 = new TacheSimple(1, "t", "t",
                "", "", date1, date2, "USD 30/heure", EtatTache.PUBLIEE, client1,
                lstInterLivTS1, hmDoCoTS1);
        System.out.println(tacheSimple1);



        // ======= création tache massive =======
        // création hashmap des domaines et des compétences pour tache massive 1
        ArrayList<Competence> lstCompDom1TM1 = new ArrayList<>();
        lstCompDom1TM1.add(c6);
        lstCompDom1TM1.add(c8);
        HashMap<Domaine, ArrayList<Competence>> hmDoCoTM1 = new HashMap<>();
        hmDoCoTM1.put(domaine2, lstCompDom1TM1);

        // création hashmap des intervenants et ses livraisons pour tache massive 1
        HashMap<Intervenant, Livraison> lstInterLivTM1 = new HashMap<>();
        lstInterLivTM1.put(intervenantPhysique1,livraison2);
        lstInterLivTM1.put(intervenantMorale1,livraison3);
        TacheMassive tacheMassive1 = new TacheMassive(1, "développement application commerciale",
                "développement une aplliacation de la gestion de commande en utilisant java et MySQL", "t", "t",
                date1, date2, "EURO 150/jour", EtatTache.PUBLIEE, client1, lstInterLivTM1, hmDoCoTM1);
        System.out.println(tacheMassive1);


        // ======= réclamation =======
        Reclamation rec1 = new Reclamation(1, "On décide de faire le remboursement au client 1 car " +
                "l'intervenant 1 a dépassé le délai sans raison.", EtatReclamation.ACCEPTEE,
                new SimpleDateFormat("2020-02-02"), new SimpleDateFormat("2020-02-04"),
                "La tâche a été dépassé le délai sans raison.", client1, intervenantPhysique1, client1,
                tacheSimple1, 1000);
    }
}
