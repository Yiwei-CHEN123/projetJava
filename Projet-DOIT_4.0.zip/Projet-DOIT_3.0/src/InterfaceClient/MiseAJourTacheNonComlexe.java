package InterfaceClient;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JButton;

public class MiseAJourTacheNonComlexe extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MiseAJourTacheNonComlexe frame = new MiseAJourTacheNonComlexe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MiseAJourTacheNonComlexe() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 563, 457);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Hello, ");
		
		JLabel lblNewLabel_1 = new JLabel("A montrer NoCli");
		
		JPanel panel = new JPanel();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(298, Short.MAX_VALUE)
					.addComponent(lblNewLabel)
					.addGap(18)
					.addComponent(lblNewLabel_1)
					.addGap(89))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(21)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 467, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(49, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_1))
					.addGap(18)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 355, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(333, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel_2 = new JLabel("Numero de tache:");
		
		JLabel lblNewLabel_3 = new JLabel("Nom de tache:");
		
		JLabel lblNewLabel_4 = new JLabel("Description:  ");
		
		JLabel lblNewLabel_16 = new JLabel("A montrer");
		
		JLabel lblNewLabel_17 = new JLabel("A montrer");
		
		JLabel lblNewLabel_18 = new JLabel("A montrer");
		
		JLabel lblNewLabel_10 = new JLabel("Competence requises:");
		
		JLabel lblNewLabel_24 = new JLabel("A montrer");
		
		JLabel lblNewLabel_11 = new JLabel("Nombre de personnes:");
		
		JLabel lblNewLabel_25 = new JLabel("A montrer");
		
		JLabel lblNewLabel_13 = new JLabel("Domaine:");
		
		JLabel lblNewLabel_26 = new JLabel("A montrer");
		
		JLabel lblNewLabel_12 = new JLabel("Lieu:");
		
		JLabel lblNewLabel_27 = new JLabel("A montrer");
		
		JLabel lblNewLabel_5 = new JLabel("Etat:");
		
		JLabel lblNewLabel_19 = new JLabel("A montrer");
		
		JLabel lblNewLabel_6 = new JLabel("Delais prevus:");
		
		JLabel lblNewLabel_20 = new JLabel("A montrer");
		
		JLabel lblNewLabel_7 = new JLabel("Delais final:");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel lblNewLabel_15 = new JLabel("Date fin:");
		
		JLabel lblNewLabel_21 = new JLabel("A montrer");
		
		JLabel lblNewLabel_22 = new JLabel("A montrer");
		
		JLabel lblNewLabel_9 = new JLabel("Montant augementer:");
		
		JLabel lblNewLabel_8 = new JLabel("Montant a payer:");
		
		JButton btnNewButton = new JButton("Valider");
		
		JButton btnNewButton_1 = new JButton("Annuler");
		
		JLabel lblNewLabel_14 = new JLabel("Montant final:");
		
		JLabel lblNewLabel_23 = new JLabel("A montrer");
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createSequentialGroup()
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_2)
										.addComponent(lblNewLabel_3)
										.addComponent(lblNewLabel_4)
										.addComponent(lblNewLabel_5)
										.addComponent(lblNewLabel_6))
									.addGap(18)
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel.createSequentialGroup()
											.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
												.addComponent(lblNewLabel_19)
												.addComponent(lblNewLabel_16)
												.addComponent(lblNewLabel_17)
												.addComponent(lblNewLabel_18))
											.addGap(39)
											.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
												.addComponent(lblNewLabel_10)
												.addComponent(lblNewLabel_11)
												.addComponent(lblNewLabel_13)
												.addComponent(lblNewLabel_12))
											.addGap(33)
											.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
												.addComponent(lblNewLabel_27)
												.addComponent(lblNewLabel_26)
												.addComponent(lblNewLabel_25)
												.addComponent(lblNewLabel_24)))
										.addComponent(lblNewLabel_20)))
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(lblNewLabel_15)
									.addGap(78)
									.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
							.addContainerGap(43, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_8)
								.addComponent(lblNewLabel_14)
								.addComponent(lblNewLabel_7))
							.addGap(25)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_23)
								.addComponent(lblNewLabel_22)
								.addComponent(lblNewLabel_21))
							.addPreferredGap(ComponentPlacement.RELATED, 141, Short.MAX_VALUE)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnNewButton)
								.addComponent(btnNewButton_1))
							.addContainerGap(66, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_9)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(273, Short.MAX_VALUE))))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(lblNewLabel_16)
						.addComponent(lblNewLabel_10)
						.addComponent(lblNewLabel_24))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(lblNewLabel_17)
						.addComponent(lblNewLabel_11)
						.addComponent(lblNewLabel_25))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(lblNewLabel_18)
						.addComponent(lblNewLabel_13)
						.addComponent(lblNewLabel_26))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_12)
						.addComponent(lblNewLabel_27)
						.addComponent(lblNewLabel_5)
						.addComponent(lblNewLabel_19))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_6)
								.addComponent(lblNewLabel_20))
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_15))
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_21)
								.addComponent(lblNewLabel_7))
							.addGap(16)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_8)
								.addComponent(lblNewLabel_22))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_9)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addComponent(btnNewButton_1)
								.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
									.addComponent(lblNewLabel_14)
									.addComponent(lblNewLabel_23))))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(102)
							.addComponent(btnNewButton)))
					.addContainerGap(35, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
	}

}
