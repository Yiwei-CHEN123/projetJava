package BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Utilisateurs.Client;
import Utilisateurs.Utilisateur;

public class UserTest {
	public Utilisateur login(Connection con,Utilisateur user)throws Exception{
		Utilisateur resUser=null;
		String sql="select * from projetutilisateur where email=? and mdp=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, user.getEmail());
		pstmt.setString(2, user.getMdp());
		ResultSet rs=pstmt.executeQuery();
		if (rs.next()) {
			resUser=new Client();
			resUser.setEmail(rs.getString("email"));
			resUser.setMdp(rs.getString("mdp"));
		}
		return resUser;
	}
}
