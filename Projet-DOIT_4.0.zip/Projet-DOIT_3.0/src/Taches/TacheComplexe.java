package Taches;

import java.util.ArrayList;

public class TacheComplexe extends Taches {
    private ArrayList<TacheMassive> lstTacheM;
    private ArrayList<TacheSimple> lstTacheS;


    public TacheComplexe(int numTache, String nomTache, String description, ArrayList<TacheSimple> lstTacheS,
                         ArrayList<TacheMassive> lstTacheM) {
        super(numTache, nomTache, description);
        this.lstTacheM = lstTacheM;
        this.lstTacheS = lstTacheS;
    }

    public ArrayList<TacheMassive> getLstTacheM() {
        return lstTacheM;
    }

    public ArrayList<TacheSimple> getLstTacheS() {
        return lstTacheS;
    }


    @Override
    public String toString() {
        return "Liste des tâche simples: " + this.getNomTS() +
                "\nListe des tâche massives: " + this.getNomTM();
    }

    public ArrayList<String> getNomTS(){
        ArrayList<String> lstTS = new ArrayList<>();
        for(TacheSimple ts : this.lstTacheS){
            lstTS.add(ts.getNomTache());
        }
        return lstTS;
    }

    public ArrayList<String> getNomTM(){
        ArrayList<String> lstTM = new ArrayList<>();
        for(TacheMassive tm : this.lstTacheM){
            lstTM.add(tm.getNomTache());
        }
        return lstTM;
    }
}