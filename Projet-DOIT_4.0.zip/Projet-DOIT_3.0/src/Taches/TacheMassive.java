package Taches;

import Utilisateurs.Client;
import Utilisateurs.Competence;
import Utilisateurs.Domaine;
import Utilisateurs.Intervenant;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class TacheMassive extends Taches {

    public TacheMassive(int numTache, String nomTache, String description, String adresseTache, String paysTache,
                        Date dateDeb, Date dateFin, String prix, EtatTache etat, Client client,
                        HashMap<Intervenant, Livraison> lstIntervenantLiv, HashMap<Domaine, ArrayList<Competence>> hmDoCo) {
        super(numTache, nomTache, description, adresseTache, paysTache, dateDeb, dateFin, prix, etat, client,
                lstIntervenantLiv, hmDoCo);
    }

    @Override
    public String getNomTache() {
        return super.getNomTache();
    }

    @Override
    public int getNbPersonne() {
        return super.getNbPersonne();
    }

    @Override
    public void setEtat(EtatTache etat) {
        super.setEtat(etat);
    }

    @Override
    public Date getDateDeb() {
        return super.getDateDeb();
    }

    @Override
    public void setDateDeb(Date dateDeb) {
        super.setDateDeb(dateDeb);
    }

    @Override
    public Date getDateFin() {
        return super.getDateFin();
    }

    @Override
    public void setDateFin(Date dateFin) {
        super.setDateFin(dateFin);
    }

//    @Override
//    public String getDelaisPrevu() {
//        return super.getDelaisPrevu();
//    }

    @Override
    public String setDelaisPrevu() {
        return super.setDelaisPrevu();
    }

    @Override
    public String getPrix() {
        return super.getPrix();
    }

    @Override
    public void setPrix(String prix) {
        super.setPrix(prix);
    }
}
