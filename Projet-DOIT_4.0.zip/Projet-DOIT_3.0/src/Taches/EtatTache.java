package Taches;

public enum EtatTache {
    ENREGISTREE,
    PUBLIEE,
    EN_COURS,
    ANNULEE,
    REALISEE,
    EN_RETARD,
    EN_COURS_DE_RECLAMATION,
    RECLAMEE,
    CLOTUREE
}
