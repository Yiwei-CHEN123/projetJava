package Taches;
import Utilisateurs.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;


// tous les type de parametres
public abstract class Taches {
	protected int numTache;
	protected String nomTache;
	protected String description;
	protected String adresseTache;
	protected String paysTache;
	protected Date dateDeb;
	protected Date dateFin;
//	protected String delaisPrevu; // type de donnée
	protected String prix;
//	protected int nbPersonne; // calculé
	protected EtatTache etat;

	// nouveaux
	protected Client client;
	protected HashMap<Intervenant, Livraison> lstIntervenantLiv;
	protected HashMap<Domaine, ArrayList<Competence>> hmDoCo; // competence qu'on a choisie pour un domaine

	public Taches(int numTache, String nomTache, String description) {
		this.numTache = numTache;
		this.nomTache = nomTache;
		this.description = description;
	}

	public Taches(int numTache, String nomTache, String description, String adresseTache, String paysTache, Date dateDeb, Date dateFin, String prix, EtatTache etat, Client client, HashMap<Intervenant, Livraison> lstIntervenantLiv, HashMap<Domaine, ArrayList<Competence>> hmDoCo) {
		this.numTache = numTache;
		this.nomTache = nomTache;
		this.description = description;
		this.adresseTache = adresseTache;
		this.paysTache = paysTache;
		this.dateDeb = dateDeb;
		this.dateFin = dateFin;
//		this.delaisPrevu = delaisPrevu;
		this.prix = prix;
//		this.nbPersonne = nbPersonne;
		this.etat = etat;
		this.client = client;
		this.lstIntervenantLiv = lstIntervenantLiv;
		this.hmDoCo = hmDoCo;
	}

	public String getNomTache() {
		return nomTache;
	}

	public int getNbPersonne() {
		return this.lstIntervenantLiv.keySet().size();
	}

	protected void setEtat(EtatTache etat) {
		this.etat = etat;
	}

	public Date getDateDeb() {
		return dateDeb;
	}

	public void setDateDeb(Date dateDeb) {
		this.dateDeb = dateDeb;
	}

	public Date getDateFin() {
		return dateFin;
	}

	public void setDateFin(Date dateFin) {
		this.dateFin = dateFin;
	}

	public String getPrix() {
		return prix;
	}

	public void setPrix(String prix) {
		this.prix = prix;
	}

//	public String getDelaisPrevu(){
//		return delaisPrevu;
////		long duree = this.dateFin.getTime() - this.dateDeb.getTime();
////		long jour = duree / (24 * 60 * 60 * 1000);
////		long heure = (duree / (60 * 60 * 1000) - jour * 24);
////		long min = ((duree / (60 * 1000)) - jour * 24 * 60 - heure * 60);
////		long s = (duree / 1000 - jour * 24 * 60 * 60 - heure * 60 * 60 - min * 60);
////		String timeDifference = jour + " jours " + heure + " heures " + min + " minutes " + s + " secondes";
////		return timeDifference;

//	}

	public String setDelaisPrevu() {
		long duree = this.dateFin.getTime() - this.dateDeb.getTime();
		long jour = duree / (24 * 60 * 60 * 1000);
		long heure = (duree / (60 * 60 * 1000) - jour * 24);
		long min = ((duree / (60 * 1000)) - jour * 24 * 60 - heure * 60);
		long s = (duree / 1000 - jour * 24 * 60 * 60 - heure * 60 * 60 - min * 60);
		String timeDifference = jour + " jours " + heure + " heures " + min + " minutes " + s + " secondes";
		return timeDifference;
	}

	@Override
	public String toString() {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		return "Client: " + this.getClient() + // récrire client
				"\nNuméro de tâche: " + numTache +
				"\nNom de tâche: " + nomTache +
				"\nDescription de tâche: " + description +
				"\nLieu de tâche: " + adresseTache +
//				"\npaysTache: " + paysTache +
				"\nDate de début: " + df.format(dateDeb) +
				"\nDate de fin: " + df.format(dateFin) +
				"\nDélais prévus: " + this.setDelaisPrevu() +
				"\nPrix(USD): " + prix +
				"\nNombre de personnes nécessitées: " + this.getNbPersonne() +
				"\nEtat: " + etat +
				"\nListe des intervenants: " + this.getIntervenant() +
				"\nListe des domaines concernés: " + this.getDomaine() +
				"\nListe des compétences requies: " + this.getCompetence()				;
	}

	public String getClient(){
		String nomCli = null;
			if(this.client instanceof PersonneMoraleC){
				nomCli = ((PersonneMoraleC) this.client).getRaisonSociale();
			}else if(this.client instanceof PersonnePhysiqueC){
				nomCli = ((PersonnePhysiqueC) this.client).getPrenom() + " " + ((PersonnePhysiqueC) this.client).getNom();
			}
		return nomCli;
	}

	public ArrayList<String> getIntervenant(){
		ArrayList<String> lstInter = new ArrayList<>();

		for(Intervenant inter : lstIntervenantLiv.keySet()){
			if(inter instanceof PersonneMoraleI){
				lstInter.add(((PersonneMoraleI) inter).getRaisonSociale());
			}else if(inter instanceof PersonnePhysiqueI){
				lstInter.add(((PersonnePhysiqueI) inter).getPrenom()+ " " + ((PersonnePhysiqueI) inter).getNom() );
			}
		}
		return lstInter;
	}

	public ArrayList<String> getDomaine(){
		ArrayList<String> lstDomaine = new ArrayList<>();

		for(Domaine domaine : hmDoCo.keySet()){
			lstDomaine.add(domaine.getNomDomaine());
		}
		return lstDomaine;
	}

	public ArrayList<String> getCompetence(){
		ArrayList<String> lstCompetence = new ArrayList<>();

		for(Domaine domaine : hmDoCo.keySet()){
			ArrayList<Competence> lst = this.hmDoCo.get(domaine);
			for(Competence competence : lst){
				lstCompetence.add(competence.getNomComp());
			}
		}
		return lstCompetence;
	}

	public void publierTache() {
		// TODO - implement Taches.publierTache
		throw new UnsupportedOperationException();
	}

	public void enregistrerTache() {
		// TODO - implement Taches.enregistrerTache
		throw new UnsupportedOperationException();
	}

	public void accepterTache() {
		// TODO - implement Taches.accepterTache
		throw new UnsupportedOperationException();
	}

	public void annulerTache() {
		// TODO - implement Taches.annulerTache
		throw new UnsupportedOperationException();
	}

	public void classerRetardTache() {
		// TODO - implement Taches.classerRetardTache
		throw new UnsupportedOperationException();
	}

	public void continuerTache() {
		// TODO - implement Taches.continuerTache
		throw new UnsupportedOperationException();
	}

	public void reclamerTache() {
		// TODO - implement Taches.reclamerTache
		throw new UnsupportedOperationException();
	}

	public void classerReclameTache() {
		// TODO - implement Taches.classerReclameTache
		throw new UnsupportedOperationException();
	}

	public void realiserTache() {
		// TODO - implement Taches.realiserTache
		throw new UnsupportedOperationException();
	}

	public void cloturerTache() {
		// TODO - implement Taches.cloturerTache
		throw new UnsupportedOperationException();
	}

	public void consulter() {
		// TODO - implement Taches.consulter
		throw new UnsupportedOperationException();
	}


}
