package Taches;

import java.util.Date;

public class Livraison {
	private String livrable;
	private Date dateLivrable;

	public Livraison(String livrable, Date dateLivrable) {
		this.livrable = livrable;
		this.dateLivrable = dateLivrable;
	}
}
