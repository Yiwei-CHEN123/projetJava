package Evaluation;

import Utilisateurs.Client;
import Utilisateurs.Intervenant;
import Utilisateurs.Utilisateur;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Evaluation {
    private float point;
    private String commentaire;
    private Date dateEvaluation;

    private Utilisateur cible;
    private Client client;
    private Intervenant intervenant;

    //creer une evaluation
    public Evaluation(float point, String commentaire, Date dateEvaluation, Utilisateur cible, Client client,
                      Intervenant intervenant) {
        this.point = point;
        this.commentaire = commentaire;
        this.dateEvaluation = dateEvaluation;
        this.cible = cible;
        this.client = client;
        this.intervenant = intervenant;
    }

    public Evaluation(float point,String commentaire,Date dateEvaluation,Client cli){
        this.point = point;
        this.commentaire = commentaire;
        this.dateEvaluation = dateEvaluation;
        this.client = cli;
    }


    public float getPoint() {
        return point;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public Date getDateEvaluation() {
        return dateEvaluation;
    }

    public Utilisateur getCible() {
        return cible;
    }

    public Client getClient() {
        return client;
    }

    public Intervenant getIntervenant() {
        return intervenant;
    }

    public void consulter(){
        // TODO
    };
}
