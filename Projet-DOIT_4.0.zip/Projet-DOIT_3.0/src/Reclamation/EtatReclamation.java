package Reclamation;

public enum EtatReclamation {
    CREEE,
    ACCEPTEE,
    REFUSEE,
    ANNULEE,
    ARCHIVEE

}
