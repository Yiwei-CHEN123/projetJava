package Reclamation;

import Taches.Taches;
import Utilisateurs.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Reclamation {
	private int numeroRec;
	private String aviRec;
	private EtatReclamation etatRec;
	private SimpleDateFormat dateRec;
	private SimpleDateFormat dateTrRec;
	private String raisonRec; // pas dans DCL

	// nouveaux
	private Utilisateur demandeur;
	private Client client;
	private Intervenant intervenant;
	private Taches tache;
	private float montantRemb;
//	private ArrayList<Reclamation> lstRec;

	public Reclamation(int numeroRec, String aviRec, EtatReclamation etatRec, SimpleDateFormat dateRec,
					   SimpleDateFormat dateTrRec, String raisonRec, Client client,  Intervenant intervenant,
					   Utilisateur demandeur,  Taches tache, float montantRemb) {
		this.numeroRec = numeroRec;
		this.aviRec = aviRec;
		this.etatRec = etatRec;
		this.dateRec = dateRec;
		this.dateTrRec = dateTrRec;
		this.raisonRec = raisonRec;
		this.demandeur = demandeur;
		this.client = client;
		this.intervenant = intervenant;
		this.tache = tache;
		this.montantRemb = montantRemb;
	}

	public EtatReclamation getEtatRec() {
		return etatRec;
	}

	public void setEtatRec(EtatReclamation etatRec) {
		this.etatRec = etatRec;
	}

	public String getDateRec() {
		return dateRec.toPattern();
	}

	public String getDateTrRec() {
		return dateTrRec.toPattern();
	}

	public Client getClient() {
		return client;
	}

	public Intervenant getIntervenant() {
		return intervenant;
	}

	@Override
	public String toString() {
		return "Numéro de réclamation: " + numeroRec +
				"\nAvis de réclamation: " + aviRec +
				"\nEtat: " + etatRec +
				"\nDate de création: " + getDateRec() +
				"\nDate de tratement: " + getDateTrRec() +
				"\nRaison: " + raisonRec +
				"\nDemandeur: " + this.getNomDemandeur() +
				"\nClient: " + this.getNomClient()+
				"\nIntervenant: " + this.getNomIntervenant() +
				"\nNom de tâche: " + tache.getNomTache() +
				"\nMontant de remboursemment: " + montantRemb;
	}

	public String getNomDemandeur(){
		String nomDemandeur = null;
		if(this.demandeur.equals(this.client)){
			nomDemandeur = this.getNomClient();
		}else if(this.demandeur.equals(this.intervenant)){
			nomDemandeur = this.getNomIntervenant();
		}
		return nomDemandeur;
	}

	public String getNomClient(){
		String nomCli = null;
		if(this.client instanceof PersonneMoraleC){
			nomCli = ((PersonneMoraleC) this.client).getRaisonSociale();
		}else if(this.client instanceof PersonnePhysiqueC){
			nomCli = ((PersonnePhysiqueC) this.client).getPrenom() + " " + ((PersonnePhysiqueC) this.client).getNom();
		}
		return nomCli;
	}

	public String getNomIntervenant(){
		String nomInter = null;
		if(this.intervenant instanceof PersonneMoraleI){
			nomInter = ((PersonneMoraleI) this.intervenant).getRaisonSociale();
		}else if(this.intervenant instanceof PersonnePhysiqueI){
			nomInter = ((PersonnePhysiqueI) this.intervenant).getPrenom() + " " + ((PersonnePhysiqueI) this.intervenant).getNom();
		}
		return nomInter;
	}



	public void accepterReclamation(int numeroRec) {

		ArrayList<Integer> lstNumRec = new ArrayList<>();

		/*for (Reclamation reclamation : this.lstRec) {
			lstNumRec.add(reclamation.numeroRec);
		}

		if (!lstNumRec.contains(numeroRec)) {
			setEtatRec(EtatReclamation.ACCEPTEE);
			lstNumRec.add(numeroRec);

		}*/

	}


	public void refuserReclamation(int numeroRec) {
		ArrayList<Integer> lstNumRec = new ArrayList<>();

		/*for (Reclamation reclamation : this.lstRec) {
			lstNumRec.add(reclamation.numeroRec);
		}

		if (!lstNumRec.contains(numeroRec)) {
			setEtatRec(EtatReclamation.REFUSEE);

		}*/
	}

	public void annulerReclamation(int numeroRec) {

		/*for (Reclamation reclamation : this.lstRec) {
			if (reclamation.numeroRec == numeroRec) {
				reclamation.setEtatRec(EtatReclamation.ANNULEE);
				this.lstRec.remove(reclamation);

			}
		}*/
	}

	public void faireReclamation() {
		// TODO - implement réclamation.faireReclamation
		throw new UnsupportedOperationException();
	}

	public void archiverReclamation() {  // lstArchivee
		// TODO - implement réclamation.archiverReclamation
		throw new UnsupportedOperationException();
	}

}
