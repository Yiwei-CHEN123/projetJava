package Reclamation;

public class Remboursement {
	private int numRemb;
	private float montantRemb;

	public Remboursement(int numRemb, float montantRemb) {
		this.numRemb = numRemb;
		this.montantRemb = montantRemb;
	}

	public void rembourser() {
		// TODO - implement Remboursement.rembourser
		throw new UnsupportedOperationException();
	}
}

