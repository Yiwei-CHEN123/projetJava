package Utilisateurs;

import java.util.Comparator;
import java.util.Date;
import java.util.Map;

class KeyValueComparator implements Comparator<Map.Entry<Date, String>> {
    enum Type {
        KEY, VALUE;
    }

    enum Order {
        ASC, DESC
    }

    private Type type;
    private Order order;

    public KeyValueComparator(Type type, Order order) {
        this.type = type;
        this.order = order;
    }


    public int compare(Map.Entry<Date, String> o1, Map.Entry<Date, String> o2) {
        switch (type) {
            case KEY:
                switch (order) {
                    case ASC:
                        return o1.getKey().compareTo(o2.getKey());
                    case DESC:
                        return o2.getKey().compareTo(o1.getKey());
                    default:
                        throw new RuntimeException("顺序参数错误");
                }
            case VALUE:
                switch (order) {
                    case ASC:
                        return o1.getValue().compareTo(o2.getValue());
                    case DESC:
                        return o2.getValue().compareTo(o1.getValue());
                    default:
                        throw new RuntimeException("顺序参数错误");
                }
            default:
                throw new RuntimeException("类型参数错误");
        }
    }

}
