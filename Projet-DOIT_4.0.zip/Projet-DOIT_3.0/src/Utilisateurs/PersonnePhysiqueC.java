package Utilisateurs;

import Evaluation.Evaluation;

import java.util.ArrayList;

public class PersonnePhysiqueC extends Client {

	private String nom;
	private String prenom;
	private String civilite;

	public PersonnePhysiqueC(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal,
							 String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval,
							 ArrayList<Domaine> lstDomaine, ArrayList<Intervenant> lstInterFavorable, String email,
							 String mdp, String nom, String prenom, String civilite) {
		super(numeroIdent, typeIdent, pays, ville, rue, codePostal, telephone, ribIban, pointEvalu, lstEval, lstDomaine, lstInterFavorable, email, mdp);
		this.nom = nom;
		this.prenom = prenom;
		this.civilite = civilite;
	}
	//connxion
	public boolean connexion(String email,String mdp){
		return super.connexion(email,mdp);
	}
	//mise a jour des coordonnees
	public void miseAJourCoordonnees (String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, ArrayList<Domaine> lstDomaine, String mdp, String nom, String prenom, String civilite){
		super.setTypeIdent(typeIdent);
		super.setPays(pays);
		super.setVille(ville);
		super.setRue(rue);
		super.setCodePostal(codePostal);
		super.setTelephone(telephone);
		super.setRibIban(ribIban);
		super.setLstDomaine(lstDomaine);
		super.setMdp(mdp);
		this.setNom(nom);
		this.setPrenom(prenom);
		this.setCivilite(civilite);
	}

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	//mise a jour lst intervenants favorables
	public void setLstInterFavorable(ArrayList<Intervenant> lstInterFavorable) {
		super.setLstInterFavorable(lstInterFavorable);
	}
	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
}
