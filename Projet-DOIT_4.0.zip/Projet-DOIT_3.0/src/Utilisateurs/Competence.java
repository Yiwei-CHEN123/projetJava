package Utilisateurs;

public class Competence {
	private int numeroComp;
	private String nomComp;

	public Competence(int numeroComp, String nomComp) {
		this.numeroComp = numeroComp;
		this.nomComp = nomComp;
	}

	public String getNomComp() {
		return nomComp;
	}

	public void getCompetence() {
		// TODO - implement Competence.getCompetence
		throw new UnsupportedOperationException();
	}

}
