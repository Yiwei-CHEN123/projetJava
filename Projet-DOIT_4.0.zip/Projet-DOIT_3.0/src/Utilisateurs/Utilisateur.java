//package Utilisateurs;
//
//import Evaluation.Evaluation;
//
//import java.util.ArrayList;
//
//public abstract class Utilisateur {
//	protected int numeroIdent;
//	private String typeIdent;
//	private String pays;
//	private String ville;
//	private String rue;
//	private String codePostal;
//	private String telephone;
//	private String ribIban;
//	private float pointEvalu;
//	private ArrayList<Evaluation> lstEval; // stocker toutes des évaluations recues
//
//	public Utilisateur(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval) {
//		this.numeroIdent = numeroIdent;
//		this.typeIdent = typeIdent;
//		this.pays = pays;
//		this.ville = ville;
//		this.rue = rue;
//		this.codePostal = codePostal;
//		this.telephone = telephone;
//		this.ribIban = ribIban;
//		this.pointEvalu = pointEvalu;
//		this.lstEval = lstEval;
//	}
//
//	public Utilisateur(){}
//
//}
package Utilisateurs;

import Evaluation.Evaluation;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

//calculer le point moyen d’évaluation
//get 10 derniers commentaires()
public abstract class Utilisateur {
	private int numeroIdent;
	private String typeIdent;
	private String pays;
	private String ville;
	private String rue;
	private String codePostal;
	private String telephone;
	private String ribIban;
	private float pointEvalu;
	private ArrayList<Evaluation> lstEval; // stocker toute les evaluations recues

	//nouveaux
	private String email;
	private String mdp;

	public Utilisateur(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval, String email, String mdp) {
		this.numeroIdent = numeroIdent;
		this.typeIdent = typeIdent;
		this.pays = pays;
		this.ville = ville;
		this.rue = rue;
		this.codePostal = codePostal;
		this.telephone = telephone;
		this.ribIban = ribIban;
		this.pointEvalu = pointEvalu;
		this.lstEval = lstEval;
		this.email = email;
		this.mdp = mdp;
	}

	//connexion des utilsiateurs
	public  boolean connexion(String email,String mdp){
		if (this.email == email && this.mdp == mdp){
			return true;
		}else return false;
	}

	public Utilisateur(String email,String mdp){
		this.mdp=mdp;
		this.email=email;
	}
	
	public Utilisateur(){

	}
	public Utilisateur(ArrayList<Evaluation> lst){
		this.lstEval = lst;
	}
	//calculer le point moyen
	public float setPointEvalu(){
		float point = 0;
		int compteur = 0;
		for (Evaluation ev:this.lstEval ) {
			if(this.equals(ev.getClient()) ){
				point = point + ev.getPoint();
				compteur++;
			}
		}
		BigDecimal bd = new BigDecimal((float)point/compteur);
		float pointMoy = bd.setScale(1, 4).floatValue();
		return pointMoy;
	}
	//obtenir 10 derniers commentaires
	public ArrayList<String> get10Commentaires(){
		ArrayList<String> lstCommentaires = new ArrayList<>();
		IdentityHashMap<Date,String> ihmDateComm = new IdentityHashMap<>();
		for (Evaluation ev:this.lstEval ) {
			if (this.equals(ev.getClient())) {
				ihmDateComm.put(ev.getDateEvaluation(),ev.getCommentaire());
			}
		}
		try {
			List<Map.Entry<Date, String>> list1 = new ArrayList<>();
			Collections.sort(list1, new KeyValueComparator(KeyValueComparator.Type.KEY, KeyValueComparator.Order.DESC));
		}catch (RuntimeException re){
			re.getStackTrace();
		}
		for (Date d:ihmDateComm.keySet()){
			lstCommentaires.add(ihmDateComm.get(d));
		}
		return lstCommentaires;
	}

	public void setNumeroIdent(int numeroIdent) {
		this.numeroIdent = numeroIdent;
	}

	public void setTypeIdent(String typeIdent) {
		this.typeIdent = typeIdent;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public void setRue(String rue) {
		this.rue = rue;
	}

	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public void setRibIban(String ribIban) {
		this.ribIban = ribIban;
	}

	public void setPointEvalu(float pointEvalu) {
		this.pointEvalu = pointEvalu;
	}

	public void setLstEval(ArrayList<Evaluation> lstEval) {
		this.lstEval = lstEval;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public int getNumeroIdent() {
		return numeroIdent;
	}

	public String getTypeIdent() {
		return typeIdent;
	}

	public String getPays() {
		return pays;
	}

	public String getVille() {
		return ville;
	}

	public String getRue() {
		return rue;
	}

	public String getCodePostal() {
		return codePostal;
	}

	public String getTelephone() {
		return telephone;
	}

	public String getRibIban() {
		return ribIban;
	}

	public ArrayList<Evaluation> getLstEval() {
		return lstEval;
	}

	public String getEmail() {
		return email;
	}

	public String getMdp() {
		return mdp;
	}

	public float getPointEvalu() {
		return pointEvalu;
	}
}
