package Utilisateurs;

import Evaluation.Evaluation;

import java.util.ArrayList;
import java.util.HashMap;

public class PersonnePhysiqueI extends Intervenant {

	private String nom;
	private String prenom;
	private String civilite;

	public PersonnePhysiqueI(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval, String email, String mdp, HashMap<Domaine, ArrayList<Competence>> hmDoCoInter, String nom, String prenom,String civitlite) {
		super(numeroIdent, typeIdent, pays, ville, rue, codePostal, telephone, ribIban, pointEvalu, lstEval, email, mdp, hmDoCoInter);
		this.nom = nom;
		this.prenom = prenom;
		this.civilite = civilite;
	}
	//connxion
	public boolean connexion(String email,String mdp){
		return super.connexion(email,mdp);
	}
	//mise a jour des coordonnees
	public void miseAJourCoordonnes (String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, String mdp,HashMap<Domaine, ArrayList<Competence>> hmDoCoInter,String nom, String prenom,String civilite) {
		super.setTypeIdent(typeIdent);
		super.setPays(pays);
		super.setVille(ville);
		super.setRue(rue);
		super.setCodePostal(codePostal);
		super.setTelephone(telephone);
		super.setRibIban(ribIban);
		super.setHmDoCoInter(hmDoCoInter);
		super.setMdp(mdp);
		this.setNom(nom);
		this.setPrenom(prenom);
		this.setCivilite(civilite);
	}
	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getCivilite() {
		return civilite;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
}