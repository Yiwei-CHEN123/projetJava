package Utilisateurs;


import Evaluation.Evaluation;

import java.util.ArrayList;
import java.util.HashMap;

public class Client extends Utilisateur{
    private ArrayList<Domaine> lstDomaine;
    private ArrayList<Intervenant> lstInterFavorable;

    public Client(){

    }
    
    public Client(ArrayList<Evaluation> lst){
        super(lst);
    }

    //inscription de client
    public Client(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal,
                  String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval,
                  ArrayList<Domaine> lstDomaine, ArrayList<Intervenant> lstInterFavorable,String email,String mdp) {
        super(numeroIdent, typeIdent, pays, ville, rue, codePostal, telephone, ribIban, pointEvalu, lstEval,email,mdp);
        this.lstDomaine = lstDomaine;
        this.lstInterFavorable = lstInterFavorable;
    }


    public Client(String userEmail, String mdp) {
		super(userEmail,mdp);
	}

	//connxion
    public boolean connexion(String email,String mdp){
        return super.connexion(email,mdp);
    }
    //mise a jour lst intervenants favorables
    public void setLstInterFavorable(ArrayList<Intervenant> lstInterFavorable) {
        this.lstInterFavorable = lstInterFavorable;
    }

    public void setLstDomaine(ArrayList<Domaine> lstDomaine) {
        this.lstDomaine = lstDomaine;
    }



    @Override
    public float setPointEvalu() {
        return super.setPointEvalu();
    }
    public float getPointEvalu() {
        return super.getPointEvalu();
    }

    @Override
    public ArrayList<String> get10Commentaires() {
        return super.get10Commentaires();
    }
}
