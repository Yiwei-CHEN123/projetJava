package Utilisateurs;

import Evaluation.Evaluation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class Intervenant extends Utilisateur {
    private HashMap<Domaine, ArrayList<Competence>> hmDoCoInter; // competence possedante par intervenant

    //inscription d'intervenant
    public Intervenant(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval, String email, String mdp,HashMap<Domaine, ArrayList<Competence>> hmDoCoInter) {
        super(numeroIdent, typeIdent, pays, ville, rue, codePostal, telephone, ribIban, pointEvalu, lstEval,email,mdp);
        this.hmDoCoInter = hmDoCoInter;
    }
    //connxion
    public boolean connexion(String email,String mdp){
        return super.connexion(email,mdp);
    }
    //mise a jour des coordonnees

    public HashMap<Domaine, ArrayList<Competence>> getHmDoCoInter() {
        return hmDoCoInter;
    }

    public void setHmDoCoInter(HashMap<Domaine, ArrayList<Competence>> hmDoCoInter) {
        this.hmDoCoInter = hmDoCoInter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Intervenant that = (Intervenant) o;
        return Objects.equals(hmDoCoInter, that.hmDoCoInter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(hmDoCoInter);
    }
}
