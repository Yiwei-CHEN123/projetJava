package Utilisateurs;

import Evaluation.Evaluation;

import java.util.ArrayList;

public class PersonneMoraleC extends Client {
	private int numEntreprise;
	private String raisonSociale;
	private String tailleEntreprise;

	public PersonneMoraleC(int numeroIdent, String typeIdent, String pays, String ville, String rue, String codePostal,
						   String telephone, String ribIban, float pointEvalu, ArrayList<Evaluation> lstEval,
						   ArrayList<Domaine> lstDomaine, ArrayList<Intervenant> lstInterFavorable, String email,
						   String mdp, int numEntreprise, String raisonSociale, String tailleEntreprise) {
		super(numeroIdent, typeIdent, pays, ville, rue, codePostal, telephone, ribIban, pointEvalu, lstEval, lstDomaine, lstInterFavorable, email, mdp);
		this.numEntreprise = numEntreprise;
		this.raisonSociale = raisonSociale;
		this.tailleEntreprise = tailleEntreprise;
	}
	//connxion
	public boolean connexion(String email,String mdp){
		return super.connexion(email,mdp);
	}
	//mise a jour des coordonnees
	public void miseAJourCoordonnees (String typeIdent, String pays, String ville, String rue, String codePostal, String telephone, String ribIban, ArrayList<Domaine> lstDomaine, String mdp, int numEntreprise, String raisonSociale, String tailleEntreprise){
		super.setTypeIdent(typeIdent);
		super.setPays(pays);
		super.setVille(ville);
		super.setRue(rue);
		super.setCodePostal(codePostal);
		super.setTelephone(telephone);
		super.setRibIban(ribIban);
		super.setLstDomaine(lstDomaine);
		super.setMdp(mdp);
		this.setNumEntreprise(numEntreprise);
		this.setRaisonSociale(raisonSociale);
		this.setTailleEntreprise(tailleEntreprise);
	}

	public String getRaisonSociale() {
		return raisonSociale;
	}

	//mise a jour lst intervenants favorables
	public void setLstInterFavorable(ArrayList<Intervenant> lstInterFavorable) {
		super.setLstInterFavorable(lstInterFavorable);
	}
	public void setNumEntreprise(int numEntreprise) {
		this.numEntreprise = numEntreprise;
	}

	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}

	public void setTailleEntreprise(String tailleEntreprise) {
		this.tailleEntreprise = tailleEntreprise;
	}
}
